import { NextResponse } from 'next/server';
import dbConnect from '@/lib/mongodb';
import Guild from '@/models/Guild';
import { getServerSession } from "next-auth/next";
import { authOptions } from "../../auth/[...nextauth]/route";

export async function GET(request, { params }) {
  await dbConnect();
  const { id } = params;
  
  let guild = await Guild.findOne({ guildId: id });
  if (!guild) {
    guild = await Guild.create({ guildId: id });
  }
  
  return NextResponse.json(guild);
}

export async function POST(request, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  await dbConnect();
  const { id } = params;
  const body = await request.json();

  const updatedGuild = await Guild.findOneAndUpdate(
    { guildId: id },
    { $set: body },
    { new: true, upsert: true }
  );

  return NextResponse.json(updatedGuild);
}
