"use client";
import { useSession } from "next-auth/react";
import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";

export default function Dashboard() {
  const { data: session, status } = useSession();
  const [guilds, setGuilds] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (session?.accessToken) {
      fetch("https://discord.com/api/users/@me/guilds", {
        headers: {
          Authorization: `Bearer ${session.accessToken}`,
        },
      })
        .then((res) => res.json())
        .then((data) => {
          // Filter guilds where user has MANAGE_GUILD permission (0x20)
          const manageable = data.filter((guild) => (guild.permissions & 0x20) === 0x20);
          setGuilds(manageable);
          setLoading(false);
        });
    }
  }, [session]);

  if (status === "loading" || loading) {
    return <div className="min-h-screen bg-discord-black flex items-center justify-center">Loading...</div>;
  }

  if (!session) {
    return <div className="min-h-screen bg-discord-black flex items-center justify-center text-white">Please login first.</div>;
  }

  return (
    <div className="min-h-screen bg-discord-black text-white p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Select a Server</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {guilds.map((guild) => (
            <Link 
              key={guild.id} 
              href={`/dashboard/${guild.id}`}
              className="bg-discord-dark p-6 rounded-lg flex items-center space-x-4 hover:scale-105 transition-transform border border-transparent hover:border-discord"
            >
              {guild.icon ? (
                <Image
                  src={`https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png`}
                  alt={guild.name}
                  width={64}
                  height={64}
                  className="rounded-full"
                />
              ) : (
                <div className="w-16 h-16 bg-discord rounded-full flex items-center justify-center text-xl font-bold">
                  {guild.name.charAt(0)}
                </div>
              )}
              <span className="text-xl font-semibold truncate">{guild.name}</span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
