"use client";
import { signIn, useSession } from "next-auth/react";
import Link from "next/link";

export default function Home() {
  const { data: session } = useSession();

  return (
    <div className="min-h-screen bg-discord-black text-white flex flex-col items-center justify-center p-4">
      <h1 className="text-5xl font-bold mb-6 text-discord">ProBot Style Dashboard</h1>
      <p className="text-xl mb-8 text-gray-400 text-center max-w-2xl">
        Manage your Discord server with ease. Configure XP systems, prefix, logs, and more from our professional dashboard.
      </p>
      
      {session ? (
        <Link 
          href="/dashboard"
          className="bg-discord hover:bg-opacity-90 text-white px-8 py-3 rounded-md font-bold text-lg transition-all"
        >
          Go to Dashboard
        </Link>
      ) : (
        <button
          onClick={() => signIn("discord")}
          className="bg-discord hover:bg-opacity-90 text-white px-8 py-3 rounded-md font-bold text-lg transition-all"
        >
          Login with Discord
        </button>
      )}
    </div>
  );
}
