# Professional Discord Bot & Dashboard

هذا المشروع عبارة عن نظام متكامل يتكون من بوت ديسكورد احترافي (discord.js v14) ولوحة تحكم ويب (Next.js) لإدارة إعدادات السيرفر، نظام الـ XP، والسجلات.

## 🚀 المميزات
- **البوت**: نظام XP/Levels، أوامر إشرافية (!kick, !ban, !warn)، سجلات، بادئة (Prefix) مخصصة.
- **لوحة التحكم**: تسجيل دخول عبر Discord OAuth2، عرض السيرفرات، تحديث الإعدادات لحظياً عبر MongoDB.
- **قاعدة البيانات**: MongoDB لتخزين بيانات المستخدمين وإعدادات السيرفرات.

## 📁 هيكل المشروع
- `bot/`: الكود المصدري لبوت الديسكورد.
- `web/`: الكود المصدري للوحة التحكم (Next.js).

## 🛠️ تعليمات التشغيل

### 1. إعداد البوت (`bot/`)
1. انتقل إلى مجلد `bot/`.
2. أنشئ ملف `.env` وأضف المتغيرات التالية:
   ```env
   TOKEN=TOKEN_البوت_الخاص_بك
   MONGODB_URI=رابط_اتصال_MONGODB
   ```
3. نفذ الأمر `npm install`.
4. نفذ الأمر `npm start`.

### 2. إعداد لوحة التحكم (`web/`)
1. انتقل إلى مجلد `web/`.
2. أنشئ ملف `.env.local` وأضف المتغيرات التالية:
   ```env
   DISCORD_CLIENT_ID=ID_التطبيق_الخاص_بك
   DISCORD_CLIENT_SECRET=SECRET_التطبيق_الخاص_بك
   NEXTAUTH_URL=http://localhost:3000
   NEXTAUTH_SECRET=كلمة_سر_عشوائية
   MONGODB_URI=رابط_اتصال_MONGODB
   ```
3. نفذ الأمر `npm install`.
4. نفذ الأمر `npm run dev`.

## 🚢 الرفع على Railway

### للبوت:
1. اربط مستودع GitHub الخاص بك بـ Railway.
2. اختر مجلد `bot/` كمسار رئيسي أو سيتعرف Railway تلقائياً على `package.json`.
3. أضف متغيرات البيئة (Environment Variables).

### للموقع:
1. اربط مستودع GitHub بـ Railway.
2. اختر مجلد `web/`.
3. أضف متغيرات البيئة (تأكد من أن `NEXTAUTH_URL` هو رابط الموقع على Railway).

## 📝 الأوامر
- `!ping`: فحص سرعة استجابة البوت.
- `!level`: عرض مستواك الحالي.
- `!kick @user [reason]`: طرد عضو.
- `!ban @user [reason]`: حظر عضو.
- `!warn @user [reason]`: تحذير عضو.
